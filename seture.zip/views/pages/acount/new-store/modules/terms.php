<div class="tab-pane container fade pt-5" id="terms">
    <!-- Modal header -->
    <div class="modal-header">
        <h4 class="modal-title text-center">1.- TERMINOS Y CONDICIONES</h4>
    </div>

    <!-- Modal body -->
    <div class="modal-body text-left p-5">
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis architecto debitis, illo nobis impedit pariatur, harum perferendis unde corporis aut, ea earum praesentium facere! Veniam ipsum suscipit veritatis molestias quibusdam.</div><br>
        <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur magnam quos voluptates maxime, voluptatibus doloribus corrupti. Vel, aliquam ducimus hic corrupti rerum architecto beatae eius at voluptate repellat quaerat animi!</div><br>
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur obcaecati, eveniet ipsum repudiandae, beatae fugit explicabo repellat earum voluptatum laudantium a nobis id debitis ipsam pariatur ab eius nemo sunt?</div><br>
        <div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Labore, molestiae, nisi quas fugiat perferendis quos aut unde vitae voluptas dolorum sunt iure ex temporibus. Quos alias harum hic maxime quibusdam!</div><br>
        <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto voluptates impedit asperiores nobis, ducimus dolore? Quas necessitatibus nesciunt ea voluptate voluptatibus ullam molestias vel quisquam porro, mollitia tempora neque tempore!</div><br>
    </div>

    <!-- Modal footer -->
    <div class="modal-footer float-left">
        <div class="form-group my-5">
            <div class="ps-checkbox">
                <input 
                type="checkbox"
                class="form-control"
                id="accept"
                onchange="aceptTermins(event)">

                <label for="accept">Aceptar terminos y condiciones</label>
            </div>
        </div>
        <label class="text-danger"><sup>*</sup>Required</label>
    </div>
</div>
<div class="clearfix"></div>