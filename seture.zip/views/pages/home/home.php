<!--=====================================
Home Content
======================================-->

<div id="homepage-6">

    <!--=====================================
    Home Banner
    ======================================-->

        <?php include "modules/horizontalSlider.php"; ?>

    <!--=====================================
    Home Promotions
    ======================================-->

        <?php //include "modules/promotionsHome.php"; ?>

    <!--=====================================
    Home Deal Hot Today
    ======================================-->

        <?php //include "modules/hotTodayHome.php"; ?>

    <!--=====================================
    Top Categoríes
    ======================================-->

        <?php //include "modules/topCategoriesHome.php"; ?>

</div><!-- End Homepage 6-->

<!--=====================================
Section Gray
======================================-->
    <?php include "modules/sectionGrayHome.php"; ?>

<!--=====================================
Home Features
======================================-->

<?php include "modules/featuresHome.php"; ?>