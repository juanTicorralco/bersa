<div class="ps-breadcrumb">

    <div class="container">

        <ul class="breadcrumb">

            <li><a href="/">Home</a></li>

            <!-- href="<?php //echo $path.$producter->url_category; ?>" -->
            <li><a ><?php echo $producter->name_category; ?></a></li>

            <!-- href="<?php //echo $path.$producter->url_subcategory; ?>" -->
            <li><a ><?php echo $producter->name_subcategory; ?></a></li>

            <li><?php echo $producter->name_product; ?></li>

        </ul>

    </div>

</div>