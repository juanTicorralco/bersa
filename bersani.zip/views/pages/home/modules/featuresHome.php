
<div class="ps-site-features">

    <div class="container">

        <div class="ps-block--site-features ps-block--site-features-2">

            <div class="ps-block__item">
                <div class="ps-block__left"><i class="icon-rocket"></i></div>
                <div class="ps-block__right">
                    <h4>Juega en cualquier lugar</h4>
                    <p>Juega y participa con tu celular, pc o tableta</p>
                </div>
            </div>

            <div class="ps-block__item">
                <div class="ps-block__left"><i class="icon-sync"></i></div>
                <div class="ps-block__right">
                    <h4>Premio al intante</h4>
                    <p>Entrega a las puertas de tu casa</p>
                </div>
            </div>

            <div class="ps-block__item">
                <div class="ps-block__left"><i class="icon-credit-card"></i></div>
                <div class="ps-block__right">
                    <h4>Pago Seguro</h4>
                    <p>100% pagos seguros con pasarelas de pago o al recibir el producto</p>
                </div>
            </div>

            <div class="ps-block__item">
                <div class="ps-block__left"><i class="icon-bubbles"></i></div>
                <div class="ps-block__right">
                    <h4>Soporte 24/7</h4>
                    <p>Soporte dedicado</p>
                </div>
            </div>

        </div>

    </div>

</div><!-- End Home Features-->